/*
Write a program in which the parent process sends two matrices to its child process through a pipe and the child process returns the sum of the matrices to the parent through a pipe. The parent should print the result.
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define SIZE 3 // Define the size of the matrix (3x3)

// Function to read a matrix from user input
void read_matrix(int matrix[SIZE][SIZE]) {
    printf("Enter matrix (%d x %d):\n", SIZE, SIZE);
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            scanf("%d", &matrix[i][j]); // Input each element of the matrix
        }
    }
}

// Function to print a matrix
void print_matrix(int matrix[SIZE][SIZE]) {
    printf("Matrix (%d x %d):\n", SIZE, SIZE);
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            printf("%d ", matrix[i][j]); // Print each element of the matrix
        }
        printf("\n"); // New line after each row
    }
}

// Function to add two matrices
void add_matrices(int a[SIZE][SIZE], int b[SIZE][SIZE], int result[SIZE][SIZE]) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            result[i][j] = a[i][j] + b[i][j]; // Add corresponding elements
        }
    }
}

int main() {
    int pipe1[2], pipe2[2]; // Define two pipes for communication
    pid_t pid;

    // Create the pipes
    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
        perror("pipe"); // Print error if pipe creation fails
        exit(EXIT_FAILURE);
    }

    // Fork a child process
    if ((pid = fork()) == -1) {
        perror("fork"); // Print error if fork fails
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { // Child process
        close(pipe1[1]); // Close unused write end of pipe1
        close(pipe2[0]); // Close unused read end of pipe2

        int matrix1[SIZE][SIZE], matrix2[SIZE][SIZE], result[SIZE][SIZE];

        // Read the two matrices from the parent process
        read(pipe1[0], matrix1, sizeof(matrix1));
        read(pipe1[0], matrix2, sizeof(matrix2));
        close(pipe1[0]); // Close read end of pipe1 after reading

        // Calculate the sum of the matrices
        add_matrices(matrix1, matrix2, result);

        // Write the result matrix to the parent process
        write(pipe2[1], result, sizeof(result));
        close(pipe2[1]); // Close write end of pipe2 after writing

        exit(EXIT_SUCCESS); // Terminate the child process
    } else { // Parent process
        close(pipe1[0]); // Close unused read end of pipe1
        close(pipe2[1]); // Close unused write end of pipe2

        int matrix1[SIZE][SIZE], matrix2[SIZE][SIZE], result[SIZE][SIZE];

        // Input the first matrix from the user
        printf("Enter the first matrix:\n");
        read_matrix(matrix1);

        // Input the second matrix from the user
        printf("Enter the second matrix:\n");
        read_matrix(matrix2);

        // Send the two matrices to the child process
        write(pipe1[1], matrix1, sizeof(matrix1));
        write(pipe1[1], matrix2, sizeof(matrix2));
        close(pipe1[1]); // Close write end of pipe1 after writing

        // Wait for the child process to complete
        wait(NULL);

        // Read the result matrix from the child process
        read(pipe2[0], result, sizeof(result));
        close(pipe2[0]); // Close read end of pipe2 after reading

        // Print the resulting matrix
        printf("Sum of the matrices:\n");
        print_matrix(result);
    }

    return 0; // End of the program
}
