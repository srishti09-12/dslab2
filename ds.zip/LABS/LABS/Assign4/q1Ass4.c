/*
Write a program to simulate logical clock synchronisation using Lamport’s logical clock algorithm and vector clocks.
*/


#include <stdio.h>
#include <stdlib.h>

// Function to get the maximum of two numbers
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Function to simulate Lamport's Logical Clock synchronization
void lamport_clock(int p1_events[], int p2_events[], int n) {
    int p1_clock = 0, p2_clock = 0;

    printf("Event\tProcess 1\tProcess 2\n");

    for (int i = 0; i < n; i++) {
        // Increment local clocks for each process
        p1_clock++;
        p2_clock++;

        // Check if there is communication between processes
        if (p1_events[i] != -1 && p2_events[i] != -1) {
            int max_clock = max(p1_clock, p2_clock) + 1;
            p1_clock = max_clock;
            p2_clock = max_clock;
        }

        // Print the current clock values for both processes
        printf("E%d\t%d\t\t%d\n", i + 1, p1_clock, p2_clock);
    }
}

int main() {
    // Define events for both processes
    // -1 indicates no communication
    int p1_events[] = {1, 0, -1, 1, 0};  // Process 1 events
    int p2_events[] = {0, 1, -1, 1, 0};  // Process 2 events
    int n = sizeof(p1_events) / sizeof(p1_events[0]);  // Number of events

    // Call the Lamport clock simulation function
    lamport_clock(p1_events, p2_events, n);

    return 0;
}
