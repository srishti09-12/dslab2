#include <stdio.h>
#include <stdlib.h>

// Global variable to maintain the logical clock
int logical_clock = 0;

// Function to simulate sending a request to enter the critical section
void send_request(int process_id) {
    logical_clock++;  // Increment logical clock for the event (sending request)
    printf("Process %d sends request at time %d\n", process_id, logical_clock);
}

// Function to simulate receiving a request from another process
void receive_request(int process_id, int sender_id, int sender_time) {
    // Synchronize the clocks: process takes the max of its own clock and sender's clock + 1
    logical_clock = (sender_time > logical_clock) ? sender_time + 1 : logical_clock + 1;  
    printf("Process %d receives request from Process %d at time %d\n", process_id, sender_id, logical_clock);
}

// Function to simulate granting permission to a process to enter the critical section
void grant_permission(int process_id, int requester_id) {
    logical_clock++;  // Increment clock when permission is granted
    printf("Process %d grants permission to Process %d at time %d\n", process_id, requester_id, logical_clock);
}

// Function to simulate a process entering the critical section
void enter_critical_section(int process_id) {
    printf("Process %d enters critical section at time %d\n", process_id, logical_clock);
}

// Function to simulate a process exiting the critical section
void exit_critical_section(int process_id) {
    printf("Process %d exits critical section at time %d\n", process_id, logical_clock);
}

int main() {
    // Simulate two processes (process 1 and process 2)
    int process_1 = 1;
    int process_2 = 2;

    // Simulate process 1 sending a request and process 2 receiving it
    send_request(process_1);  // Process 1 sends request to enter critical section
    receive_request(process_2, process_1, logical_clock);  // Process 2 receives request from process 1

    // Process 2 grants permission for process 1 to enter the critical section
    grant_permission(process_2, process_1);  
    enter_critical_section(process_1);  // Process 1 enters critical section
    exit_critical_section(process_1);  // Process 1 exits critical section

    // Simulate process 2 sending a request and process 1 receiving it
    send_request(process_2);  // Process 2 sends request to enter critical section
    receive_request(process_1, process_2, logical_clock);  // Process 1 receives request from process 2

    // Process 1 grants permission for process 2 to enter the critical section
    grant_permission(process_1, process_2);  
    enter_critical_section(process_2);  // Process 2 enters critical section
    exit_critical_section(process_2);  // Process 2 exits critical section

    return 0;
}
