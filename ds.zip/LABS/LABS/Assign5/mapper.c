#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <string.h>
#include <inttypes.h>  // For PRIdMAX and intmax_t

int main() {
   struct stat fileStat;
   struct passwd *pw;
   char filename[1024];
  
   // Read file names from stdin
   while (fgets(filename, sizeof(filename), stdin)) {
       filename[strcspn(filename, "\n")] = 0;  // Remove newline
      
       // Get file stats
       if (stat(filename, &fileStat) < 0) {
           continue;
       }
      
       // Get file owner
       pw = getpwuid(fileStat.st_uid);
      
       // Output: owner and file size
       printf("%s %jd\n", pw->pw_name, (intmax_t)fileStat.st_size);
   }
  
   return 0;
}


//ls > input.txt

//  ./mapper < input_file.txt > mapper_output.txt