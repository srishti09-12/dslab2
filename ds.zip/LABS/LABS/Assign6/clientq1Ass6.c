#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

// Define constants for the port and buffer size
#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sock = 0;  // Socket file descriptor
    struct sockaddr_in serv_addr;  // Structure to store server address information
    char buffer[BUFFER_SIZE];  // Buffer for sending and receiving data

    // Create the socket (TCP)
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("Socket creation failed");  // If socket creation fails, print error and exit
        return -1;
    }

    // Configure the server address structure
    serv_addr.sin_family = AF_INET;  // Use IPv4 addresses
    serv_addr.sin_port = htons(PORT);  // Convert the port to network byte order

    // Convert the IP address to binary format and set it in the server address
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Invalid address");  // If the IP address conversion fails, print error and exit
        return -1;
    }

    // Establish a connection to the server
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection failed");  // If connection fails, print error and exit
        return -1;
    }

    // Infinite loop to send messages to the server and receive echoed responses
    while (1) {
        printf("Enter message: ");  // Prompt the user to enter a message
        fgets(buffer, sizeof(buffer), stdin);  // Read user input into the buffer

        // Send the message to the server
        if (send(sock, buffer, strlen(buffer), 0) == -1) {
            perror("Send failed");  // If sending fails, print error and break the loop
            break;
        }

        // Read the response from the server
        ssize_t bytes_read = read(sock, buffer, sizeof(buffer) - 1);
        if (bytes_read <= 0) {
            printf("Connection closed\n");  // If the server closes the connection, exit the loop
            break;
        }

        // Null-terminate the received data to ensure it is a valid string
        buffer[bytes_read] = '\0';

        // Print the server's echo response
        printf("Echo from server: %s", buffer);
    }

    close(sock);  // Close the socket when done
    return 0;  // Return success
}
