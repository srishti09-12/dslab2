#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080 // Port number to connect to

int main()
{
    int sock = 0; // Socket file descriptor
    struct sockaddr_in serv_addr; // Server address structure
    char buffer[1024] = {0}; // Buffer to store data for sending and receiving

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0); // Create a TCP socket
    serv_addr.sin_family = AF_INET; // Use IPv4
    serv_addr.sin_port = htons(PORT); // Set the port number (network byte order)
    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr); // Convert IP to binary format

    // Connect to the server
    connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)); // Establish connection

    // Client node information (to send to the server)
    int node_no = 4; // Node number (example: 4)
    char ip_address[20] = "192.168.1.10"; // Client's IP address
    int port_no = 5678; // Client's port number

    // Send client information to the server
    sprintf(buffer, "%d %s %d", node_no, ip_address, port_no); // Format data into the buffer
    send(sock, buffer, strlen(buffer), 0); // Send the data to the server

    // Receive the updated master table from the server
    printf("Updated Master Table from Server:\n");
    while (read(sock, buffer, 1024) > 0) // Keep reading until the server stops sending data
    {
        printf("%s", buffer); // Print the received data
    }

    close(sock); // Close the socket after communication ends
    return 0; // End the program
}
