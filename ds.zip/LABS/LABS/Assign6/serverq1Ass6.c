#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

// Define constants for port number and maximum clients
#define PORT 8080
#define MAX_CLIENTS 10

// Initialize a mutex to protect shared resources like thread_count
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int thread_count = 0;  // Keep track of the number of active threads

// Function to handle communication with a client
void *handle_client(void *client_socket) {
    int sock = *(int *)client_socket;  // Get the client socket descriptor
    char buffer[1024];  // Buffer to hold incoming and outgoing data
    
    // Keep reading data from the client and echoing it back until the connection is closed
    while (1) {
        int n = read(sock, buffer, sizeof(buffer));  // Read data from client
        if (n <= 0)  // If reading fails or the client closes the connection, exit the loop
            break;
        write(sock, buffer, n);  // Echo the received data back to the client
    }
    
    // Close the client socket when communication ends
    close(sock);
    return NULL;
}

int main() {
    int server_fd, new_socket;  // Server socket and new client socket
    struct sockaddr_in address;  // Structure to store server address
    int opt = 1, addrlen = sizeof(address);  // Option for setsockopt and address length
    pthread_t threads[MAX_CLIENTS];  // Array to store thread IDs
    
    // Create the server socket (TCP)
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        perror("Socket creation failed");  // Print error and exit if socket creation fails
        return -1;
    }

    // Set the socket option to reuse the address, so the server can restart without delay
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // Configure server address
    address.sin_family = AF_INET;  // Use IPv4 addresses
    address.sin_addr.s_addr = INADDR_ANY;  // Accept connections from any IP address
    address.sin_port = htons(PORT);  // Use the defined port number, converted to network byte order

    // Bind the server socket to the defined address and port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");  // Print error and exit if bind fails
        return -1;
    }

    // Start listening for incoming client connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");  // Print error and exit if listen fails
        return -1;
    }

    // Main loop to accept and handle client connections
    while (1) {
        // Accept a new client connection
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen);
        if (new_socket < 0) {
            perror("Accept failed");  // Print error if accept fails
            continue;  // Continue accepting other clients
        }

        // Protect access to thread_count by locking the mutex
        pthread_mutex_lock(&mutex);

        // Check if there is space for more threads (clients)
        if (thread_count < MAX_CLIENTS) {
            // Create a new thread to handle the client
            pthread_create(&threads[thread_count++], NULL, handle_client, (void *)&new_socket);
        } else {
            // Reject the connection if the maximum number of clients is reached
            printf("Max clients reached. Connection rejected.\n");
            close(new_socket);  // Close the client socket without processing
        }

        // Unlock the mutex after updating the thread count
        pthread_mutex_unlock(&mutex);
    }
    
    // Close the server socket (this point will never be reached due to the infinite loop)
    close(server_fd);
    return 0;
}
