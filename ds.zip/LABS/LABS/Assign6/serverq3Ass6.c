#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define PORT 8080

void get_cpu_load(char *buffer)
{
    FILE *fp = fopen("/proc/loadavg", "r");
    if (fp == NULL) {
        perror("Failed to open /proc/loadavg");
        return;
    }
    fgets(buffer, 256, fp);
    fclose(fp);
}

int main()
{
    int server_fd, new_socket;
    struct sockaddr_in address;
    char buffer[256];
    time_t now;
    struct tm *tm_info;

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        return -1;
    }

    // Set up server address
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Bind socket to the port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        close(server_fd);
        return -1;
    }

    // Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        close(server_fd);
        return -1;
    }

    printf("Server listening on port %d\n", PORT);

    while (1)
    {
        new_socket = accept(server_fd, NULL, NULL);
        if (new_socket < 0) {
            perror("Accept failed");
            continue; // Continue accepting new connections
        }

        now = time(NULL);
        tm_info = localtime(&now);
        strftime(buffer, 256, "Current Date and Time: %Y-%m-%d %H:%M:%S\n", tm_info);
        strcat(buffer, "CPU Load: ");
        get_cpu_load(buffer + strlen(buffer));

        // Send data to the client
        if (send(new_socket, buffer, strlen(buffer), 0) < 0) {
            perror("Send failed");
        }

        // Close the client connection
        close(new_socket);
    }

    // Close the server socket
    close(server_fd);
    return 0;
}
