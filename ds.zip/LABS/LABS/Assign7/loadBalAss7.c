#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SERVER1_PORT 12345
#define SERVER2_PORT 12346
#define BUFFER_SIZE 1024


float get_cpu_load(int port) {
    int sock;
    struct sockaddr_in server_addr;
    float cpu_load;

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Send "CPU" request and receive CPU load value
    send(sock, "CPU", 3, 0);
    if (recv(sock, &cpu_load, sizeof(cpu_load), 0) < 0) {
        perror("Receive failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    close(sock);
    return cpu_load;
}

void send_string_to_server(int port, char *str, char *result) {
    int sock;
    struct sockaddr_in server_addr;

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Send the string to the server
    send(sock, str, strlen(str), 0);

    // Receive the result from the server
    memset(result, 0, BUFFER_SIZE); // Clear the result buffer
    if (recv(sock, result, BUFFER_SIZE, 0) < 0) {
        perror("Receive failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    close(sock);
}

int main() {
    int broker_socket, client_socket;
    struct sockaddr_in broker_addr, client_addr;
    char buffer[BUFFER_SIZE], result[BUFFER_SIZE];
    socklen_t addr_len;

    // Create broker socket
    broker_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (broker_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    broker_addr.sin_family = AF_INET;
    broker_addr.sin_port = htons(12347); // Load balancer port
    broker_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the broker socket
    if (bind(broker_socket, (struct sockaddr *)&broker_addr, sizeof(broker_addr)) < 0) {
        perror("Bind failed");
        close(broker_socket);
        exit(EXIT_FAILURE);
    }

    // Start listening
    if (listen(broker_socket, 5) < 0) {
        perror("Listen failed");
        close(broker_socket);
        exit(EXIT_FAILURE);
    }

    printf("Load Balancer listening on port 12347...\n");

    while (1) {
        addr_len = sizeof(client_addr);
        client_socket = accept(broker_socket, (struct sockaddr *)&client_addr, &addr_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        printf("Accepted connection from client...\n");

        // Receive string from client
        memset(buffer, 0, BUFFER_SIZE); // Clear the buffer
        if (recv(client_socket, buffer, BUFFER_SIZE, 0) < 0) {
            perror("Receive failed");
            close(client_socket);
            continue;
        }

        // Null-terminate the buffer string
        buffer[strlen(buffer)] = '\0'; 

        // Get CPU load from both servers
        float cpu1 = get_cpu_load(SERVER1_PORT);
        float cpu2 = get_cpu_load(SERVER2_PORT);
        printf("CPU load - Server 1: %.2f, Server 2: %.2f\n", cpu1, cpu2);

        // Choose server based on CPU load
        if (cpu1 < cpu2) {
            send_string_to_server(SERVER1_PORT, buffer, result);
        } else {
            send_string_to_server(SERVER2_PORT, buffer, result);
        }

        // Send result back to client
        send(client_socket, result, strlen(result), 0);
        printf("Sent result back to client: %s\n", result);

        close(client_socket);
    }

    close(broker_socket);
    return 0;
}
