#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <ctype.h>

#define SERVER_PORT 12345
#define BUFFER_SIZE 1024

void to_upper_case(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = toupper((unsigned char)str[i]);  // Convert each character to uppercase
    }
}

int main() {
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];
    socklen_t addr_len;

    // Create socket
    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_sock, 5) < 0) {
        perror("Listen failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", SERVER_PORT);

    // Accept client connection
    addr_len = sizeof(client_addr);
    client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &addr_len);
    if (client_sock < 0) {
        perror("Accept failed");
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    printf("Accepted connection from client...\n");

    // Receive the string from client
    memset(buffer, 0, BUFFER_SIZE);
    if (recv(client_sock, buffer, BUFFER_SIZE, 0) < 0) {
        perror("Receive failed");
        close(client_sock);
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    // Convert the string to uppercase
    to_upper_case(buffer);

    // Send the uppercase string back to the client
    if (send(client_sock, buffer, strlen(buffer), 0) < 0) {
        perror("Send failed");
        close(client_sock);
        close(server_sock);
        exit(EXIT_FAILURE);
    }

    printf("Sent uppercase string to client: %s\n", buffer);

    // Close the connections
    close(client_sock);
    close(server_sock);

    return 0;
}
