#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080          // Port on which the server is running
#define BUFFER_SIZE 1024   // Buffer size for data transfer

// Function to write the received file data to a local file
void writeFile(int sockfd, const char *filename) {
    char buffer[BUFFER_SIZE];
    FILE *fp = fopen(filename, "w");  // Open the file in write mode
    if (fp == NULL) {
        perror("Error opening file");  // Print error if the file cannot be opened
        exit(EXIT_FAILURE);
    }

    // Continuously receive data from the server and write it to the file
    while (1) {
        int n = recv(sockfd, buffer, BUFFER_SIZE, 0);  // Receive data from the server
        if (n <= 0) {  // Break if no more data is received or an error occurs
            break;
        }
        fprintf(fp, "%s", buffer);  // Write the data to the file
        memset(buffer, 0, BUFFER_SIZE);  // Clear the buffer for the next chunk of data
    }
    fclose(fp);  // Close the file after writing
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char filename[BUFFER_SIZE];

    // Step 1: Create a socket
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");  // Print error if socket creation fails
        exit(EXIT_FAILURE);
    }

    // Step 2: Configure server address structure
    server_addr.sin_family = AF_INET;         // Use IPv4
    server_addr.sin_port = htons(PORT);       // Set the port number (convert to network byte order)

    // Convert IP address from text to binary form and store in server_addr
    if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0) {
        perror("Invalid address");  // Print error if the IP address is invalid
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Step 3: Connect to the server
    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");  // Print error if connection to the server fails
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Step 4: Request the filename from the user
    printf("Enter the filename to request: ");
    scanf("%s", filename);

    // Step 5: Send the requested filename to the server
    send(sockfd, filename, sizeof(filename), 0);

    // Step 6: Receive the file from the server and save it locally
    printf("Receiving file...\n");
    writeFile(sockfd, filename);  // Save the received file with the same name as requested
    printf("File received and saved as '%s'.\n", filename);

    // Step 7: Close the socket
    close(sockfd);
    return 0;
}
