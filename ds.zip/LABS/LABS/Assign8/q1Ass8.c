
/*Write a program to find out the list of users who owns a file having maximum size in 
the current working directory using Map Reduce Program.
    */

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include <pthread.h>
#include <string.h>

#define MAX_FILES 1024   // Maximum number of files that can be processed
#define MAX_USERS 128    // Maximum number of users (not used directly but can be modified)

typedef struct {
    char filename[256];  // File name
    off_t size;          // File size in bytes
    char user[64];       // Username of the file owner
} FileInfo;

typedef struct {
    FileInfo *files;    // Array of FileInfo structs
    int start;           // Starting index for the files this thread will process
    int end;             // Ending index for the files this thread will process
    FileInfo maxFile;   // The largest file found in this thread's range
} MapTask;

FileInfo globalMaxFile;  // Holds the file with the maximum size found across all threads
pthread_mutex_t mutex;   // Mutex to protect access to globalMaxFile

// Function to get the username from a given UID
void getUsername(uid_t uid, char *user) {
    struct passwd *pwd = getpwuid(uid);
    if (pwd) {
        strcpy(user, pwd->pw_name);  // Copy the username into the user string
    } else {
        strcpy(user, "unknown");  // If UID not found, set username as "unknown"
    }
}

// Function to be executed by each thread (Map task)
void *mapTask(void *arg) {
    MapTask *task = (MapTask *)arg;   // Cast argument to MapTask
    FileInfo localMax = task->files[task->start];  // Start with the first file in this thread's range

    // Loop through the files assigned to this thread and find the largest file
    for (int i = task->start; i <= task->end; i++) {
        if (task->files[i].size > localMax.size) {
            localMax = task->files[i];  // Update localMax if a larger file is found
        }
    }

    // Use mutex to safely update the globalMaxFile shared by all threads
    pthread_mutex_lock(&mutex);
    if (localMax.size > globalMaxFile.size) {
        globalMaxFile = localMax;  // Update globalMaxFile with the largest file found by this thread
    }
    pthread_mutex_unlock(&mutex);

    return NULL;  // Thread finishes execution
}

// Function to process the results (Reduce task)
void reduceTask(FileInfo *files, int count, off_t maxSize) {
    printf("Files with maximum size (%ld bytes):\n", maxSize);
    // Loop through all files and print those that match the maximum size
    for (int i = 0; i < count; i++) {
        if (files[i].size == maxSize) {
            printf("File: %s, Owner: %s\n", files[i].filename, files[i].user);
        }
    }
}

int main() {
    DIR *dir;
    struct dirent *entry;
    struct stat fileStat;
    FileInfo files[MAX_FILES];  // Array to hold information about each file
    int fileCount = 0;          // Counter to track number of files

    // Initialize globalMaxFile size to 0
    globalMaxFile.size = 0;

    // Open the current directory (".") for reading
    if ((dir = opendir(".")) == NULL) {
        perror("opendir");
        return EXIT_FAILURE;  // Return failure if directory can't be opened
    }

    // Read all files in the directory and gather their information
    while ((entry = readdir(dir)) != NULL) {
        // Only process regular files (not directories, symbolic links, etc.)
        if (stat(entry->d_name, &fileStat) == 0 && S_ISREG(fileStat.st_mode)) {
            strcpy(files[fileCount].filename, entry->d_name);  // Store file name
            files[fileCount].size = fileStat.st_size;  // Store file size
            getUsername(fileStat.st_uid, files[fileCount].user);  // Store file owner username
            fileCount++;  // Increment file count
        }
    }
    closedir(dir);  // Close the directory after processing

    // If no files were found, print a message and exit
    if (fileCount == 0) {
        printf("No files found in the current directory.\n");
        return EXIT_SUCCESS;
    }

    // Initialize mutex for thread synchronization
    pthread_mutex_init(&mutex, NULL);

    int numThreads = 4;  // Set number of threads to use for parallel processing
    pthread_t threads[numThreads];  // Array to hold thread IDs
    MapTask tasks[numThreads];  // Array to hold MapTask data for each thread
    int filesPerThread = fileCount / numThreads;  // Determine how many files each thread will process

    // Create threads and assign tasks
    for (int i = 0; i < numThreads; i++) {
        tasks[i].files = files;
        tasks[i].start = i * filesPerThread;
        tasks[i].end = (i == numThreads - 1) ? fileCount - 1 : (i + 1) * filesPerThread - 1;  // Handle last thread's extra files

        pthread_create(&threads[i], NULL, mapTask, &tasks[i]);  // Create thread
    }

    // Wait for all threads to complete
    for (int i = 0; i < numThreads; i++) {
        pthread_join(threads[i], NULL);  // Wait for thread to finish execution
    }

    // After all threads finish, process the results
    reduceTask(files, fileCount, globalMaxFile.size);  // Call reduce task to print files with maximum size

    // Destroy mutex after it's no longer needed
    pthread_mutex_destroy(&mutex);

    return EXIT_SUCCESS;  // Return success after processing
}
