#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080          // Port number on which the server listens
#define BUFFER_SIZE 1024   // Buffer size for file transfer

// Function to send the file content to the client
void sendFile(FILE *fp, int sockfd) {
    char buffer[BUFFER_SIZE];

    // Read the file content line by line and send it to the client
    while (fgets(buffer, BUFFER_SIZE, fp) != NULL) {
        if (send(sockfd, buffer, sizeof(buffer), 0) == -1) {
            perror("Error sending file.");  // Print an error if the file sending fails
            exit(EXIT_FAILURE);
        }
        memset(buffer, 0, BUFFER_SIZE);  // Clear the buffer for the next chunk of data
    }
}

int main() {
    int server_fd, new_socket;
    struct sockaddr_in address;
    socklen_t addr_len = sizeof(address);
    char filename[BUFFER_SIZE];

    // Step 1: Create a socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket failed");  // Print error if socket creation fails
        exit(EXIT_FAILURE);
    }

    // Step 2: Configure server address
    address.sin_family = AF_INET;          // Use IPv4
    address.sin_addr.s_addr = INADDR_ANY;  // Listen on all available interfaces
    address.sin_port = htons(PORT);       // Set port number (convert to network byte order)

    // Step 3: Bind the socket to the specified address and port
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");  // Print error if binding fails
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    // Step 4: Listen for incoming connections
    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");  // Print error if listening fails
        close(server_fd);
        exit(EXIT_FAILURE);
    }
    printf("Server listening on port %d...\n", PORT);

    // Step 5: Accept and process client requests in an infinite loop
    while (1) {
        printf("Waiting for a connection...\n");

        // Accept a client connection
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, &addr_len)) < 0) {
            perror("Accept failed");  // Print error if connection acceptance fails
            continue;  // Skip to the next iteration and wait for another connection
        }
        printf("Client connected.\n");

        // Step 6: Receive the filename requested by the client
        recv(new_socket, filename, BUFFER_SIZE, 0);
        printf("File requested: %s\n", filename);

        // Step 7: Try to open the requested file
        FILE *fp = fopen(filename, "r");
        if (fp == NULL) {  // If the file is not found
            perror("File not found");
            send(new_socket, "File not found.\n", 17, 0);  // Notify the client that the file is missing
        } else {  // If the file exists
            sendFile(fp, new_socket);  // Send the file content to the client
            fclose(fp);  // Close the file after sending
            printf("File sent successfully.\n");
        }

        // Step 8: Close the connection with the current client
        close(new_socket);
    }

    // Step 9: Close the server socket (this line is unreachable due to the infinite loop)
    close(server_fd);
    return 0;
}
